-All text files are written to the project folder using the
System.getProperty("user.dir").

-All text files contain comma-separated-values.

-The file path containing all portfolios is "userDir-path/Investor_Profile".

-Each portfolio consists of a directory, and two files containing general
descriptive data, as well as information pertaining to certain holdings.

-All files containing data are in .txt format.
